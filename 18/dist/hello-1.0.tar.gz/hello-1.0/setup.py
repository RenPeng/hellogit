#!/usr/bin/env python
# -*- coding=utf-8 -*-
from distutils.core import setup

setup(name='hello',
        version='1.0',
        description='say hello',
        py_modules=['hello']
        )
